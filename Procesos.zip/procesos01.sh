#!/bin/bash
clear
OPTION=t
#Hacemos un bucle para que muestre un menú, con todas las opciones de las cosas que se pueden hacer.
while [ $OPTION != "q" ]; do
	echo "== ADMINISTRADOR DE PROCESOS TÁCTICO =="
	echo "- Press : p -> Report a snapshot of the current processes"
	echo "- Press : c -> Count then number of processes"
	echo "Select an option"
	read OPTION
	clear
	sleep 0.3
	#Si pulsa <p> le muestra los procesos
	if [ $OPTION = "p" ]; then
		ps -aux | more
		echo ""
	elif [ $OPTION = "c" ]; then
	#Si pulsa la <c> le muestra la cantidad de procesos
		contar=$(ps -aux | wc -l)
		echo "At present, there are "$contar" processes"
		echo ""

	else
		echo "[Unknown Option]: Please select p or c"
	fi
done

exit 0
