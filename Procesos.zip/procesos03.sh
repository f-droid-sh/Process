#!/bin/bash
resp=55
#Con este bucle hacemos que exclusivamente sea entre 1 y 10
while ! [ $resp -ge 1 -a $resp -le 10 ]; do
	read -p "Dime un número entre 1 y 10: " resp
	echo ""
	#Si no está dentro del rango te muestra un mensaje de error
	if [ $resp -le 0 -o $resp -ge 10 ]; then
		echo "¡Error!"
		echo "Debe introducir un número entre 1 y 10"
	fi
	sleep 1
done
#Como la primera linea es la que te muestra que es cada columna, le hacemos una sunma  para que muestre el menú
let resp=resp+1
echo ""
#Ejecutamos una linea para que nos ordene la RAM usada respecto a lo que diga el usuario
ps -aux | awk '{print $2, $4, $11}' | sort -k2r | head -n $resp

exit 0
