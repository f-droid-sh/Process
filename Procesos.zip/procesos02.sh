#!/bin/bash
clear
opcion=n
#Hacemos un menú para que el usuario pueda elegir una opción
while [ $opcion != "q" ]; do
#Si elige la <q> sale del bucle
	echo "Introduzca estas letras para realizar estas funciones -->"
	echo "Pulsa <c> para abrir la calculadora"
	echo "Pulsa <d> para abrir la aplicación de dia"
	echo "Pulsa <m> para abrir el bloc de notas"
	echo "Pulsa <q> para salir"
	read opcion
	#Si es una <c> te abre la calculadora
	clear
	sleep 0.3
	if [ $opcion = "c" ]; then
		echo "Abriendo calculadora..."
		sleep 1
		mate-calc &
		echo ""
	fi
	#Si es una <d> te abre la aplicación de dia
	if [ $opcion = "d" ]; then
		echo "Abriendo dia..."
		sleep 1
		dia &
		echo ""
	fi
	#Si es una <m> te abre el bloc de notas
	if [ $opcion = "m" ]; then
		echo "Abriendo el bloc de notas..."
		sleep 1
		mousepad &
		echo ""
	fi
done

exit 0
